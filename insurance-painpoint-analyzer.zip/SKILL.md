---
name: insurance-painpoint-analyzer
description: |
  Insurance industry pain point analysis and product matching tool. This skill should be used when:
  (1) Users want to research pain points in the insurance industry (general or company-specific)
  (2) Users want to match identified pain points with GBase Support product features
  (3) Users want to generate an HTML report showing the analysis results
  The skill performs web searches to gather current industry pain points, matches them with product features,
  and generates a professional HTML report for sales or business development purposes.
---

# Insurance Painpoint Analyzer

This skill analyzes insurance industry pain points and matches them with GBase Support product features, generating professional HTML reports.

## Purpose

To help sales and business development teams:
- Identify current pain points in the insurance industry
- Research specific insurance company challenges
- Match pain points with GBase Support product capabilities
- Generate professional HTML reports for presentations

## Workflow

### Step 1: Gather Pain Point Information

Based on user input, determine the scope of analysis:

**For general industry analysis:**
- Use WebSearch to find recent articles about insurance industry challenges in Japan
- Search queries to use:
  - "保険業界 課題 2025"
  - "生命保険会社 DX 課題"
  - "保険 カスタマーサポート 問題点"
  - "保険業界 人手不足"
  - "保険 デジタル化 遅れ"

**For specific company analysis:**
- Search for the company name + pain points/challenges
- Look for news articles, press releases, or industry reports
- Search queries to use:
  - "[会社名] 課題"
  - "[会社名] DX 取り組み"
  - "[会社名] 顧客対応"

### Step 2: Categorize Pain Points

Organize findings into these categories:

1. **Customer Service (顧客対応)**
   - Response time issues
   - After-hours support
   - Multilingual support needs

2. **Digital Transformation (DX推進)**
   - Legacy system limitations
   - Paper-based processes
   - IT talent shortage

3. **Knowledge Management (知識管理)**
   - Information silos
   - Document retrieval difficulties
   - Training and onboarding

4. **Compliance & Security (コンプライアンス)**
   - Regulatory requirements
   - Data protection
   - Audit trails

5. **Cost Efficiency (コスト効率)**
   - Labor costs
   - Operational efficiency
   - Resource allocation

### Step 3: Match with Product Features

Read the product features reference file:
```
references/product-features.md
```

For each pain point, identify matching features using the "適用痛点関键词" column.

Calculate match scores:
- **High Match (高)**: Direct feature addressing the pain point
- **Medium Match (中)**: Feature partially addresses the pain point
- **Low Match (低)**: Feature tangentially related

### Step 4: Generate HTML Report

Use the template from:
```
assets/report-template.html
```

Replace placeholders with actual content:

| Placeholder | Description |
|-------------|-------------|
| `{{REPORT_TITLE}}` | Report title (e.g., "保険業界ペインポイント分析レポート") |
| `{{REPORT_SUBTITLE}}` | Subtitle with scope |
| `{{REPORT_DATE}}` | Current date |
| `{{COMPANY_NAME}}` | Target company or "保険業界全般" |
| `{{PAINPOINT_COUNT}}` | Number of pain points identified |
| `{{FEATURE_COUNT}}` | Number of matching features |
| `{{MATCH_COUNT}}` | Number of high matches |
| `{{MATCH_RATE}}` | Match rate percentage |
| `{{SECTION_PAINPOINTS}}` | Section header for pain points |
| `{{PAINPOINT_CONTENT}}` | HTML content for pain points list |
| `{{SECTION_MATCHING}}` | Section header for matching |
| `{{MATCHING_CONTENT}}` | HTML table of matches |
| `{{SECTION_RECOMMENDATIONS}}` | Section header for recommendations |
| `{{RECOMMENDATION_CONTENT}}` | HTML content for recommendations |

### Step 5: Output the Report

Save the generated HTML file to the user's specified location or the current working directory.

## Output Format

The HTML report includes:

1. **Executive Summary**
   - Total pain points identified
   - Matching features count
   - Overall match rate

2. **Pain Point Analysis**
   - Categorized list of pain points
   - Sources and context

3. **Feature Matching Matrix**
   - Pain point to feature mapping
   - Match scores with visual indicators

4. **Recommendations**
   - Prioritized features to highlight
   - Suggested talking points for sales

## Example Usage

**User prompt examples:**
- "保険業界の痛点を分析して、GBase Supportとのマッチングレポートを作成して"
- "日本生命の課題を調べて、当社製品との適合性をHTML報告書にまとめて"
- "生命保険会社向けの提案資料を作成するため、業界の課題を調査して"

**Expected output:**
- HTML file with comprehensive analysis
- Visual matching indicators
- Actionable recommendations

## Language Support

This skill supports generating reports in:
- Japanese (default)
- Chinese
- English

Specify the desired language in the prompt if not Japanese.

## Notes

- Always cite sources when presenting pain point information
- Update search queries to include the current year for recent information
- Consider the specific context of each insurance company when doing targeted analysis
- The product features reference may need periodic updates as GBase Support evolves
